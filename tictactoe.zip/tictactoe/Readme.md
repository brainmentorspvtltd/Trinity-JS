1. Design a TicTacToe (HTML, CSS) - Done
2. Attach Click on button, on click call some function
function has some logic - Done
3. Print X or 0.
4. Which button is get clicked 
5. Game Over (Win or Draw)
5.1 Row Same
