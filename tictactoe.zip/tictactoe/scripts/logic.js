// HTML - Skeleton
// Access HTML Button
// DOM 
var buttons = document.getElementsByTagName('button');
console.log(buttons.length);
for(var i = 0; i<buttons.length; i++){
    buttons[i].addEventListener('click', show);
}
var isZero = false;
var clickCount = 0 ;
function show(){
    //console.log(this);
    
    if(this.innerText.length==0){
        clickCount++;
   
    var val = isZero?"0":"X";
    this.innerText = val;
    if(clickCount>=5){
        document.getElementsByTagName('h1')[0].innerText = isGameOver()?"Game Over ":"";
    }
    console.log(" I am the Show ", val);
    isZero = !isZero;
    }
}



function isGameOver(){
   // console.log('Game Over call');
   if(isSameRow(buttons[0], buttons[1], buttons[2])){
        return true;
   }
   else
   if(isSameRow(buttons[0], buttons[3], buttons[6])){
    return true;
}

    return false;
}
function isButtonNotBlank(one){
    console.log(one.innerText.length, one.innerText);
    return one.innerText.length>0;
}

function isSameRow(one, two, third){
    var result = isButtonNotBlank(one) && isButtonNotBlank(two) && isButtonNotBlank(third);
    console.log('Result is ',result);
    if(!result){
        return false;
    }
    var r =  one.innerText == two.innerText && one.innerText == third.innerText;
    console.log('R is ',r);
    return r;
}